package com.chlqudco.develop.electronicframe

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import java.util.*
import kotlin.concurrent.timer

class PhotoFrameActivity : AppCompatActivity() {

    val backgroundPhotoImageView : ImageView by lazy { findViewById(R.id.backgroundPhotoImageView) }
    val photoImageView : ImageView by lazy { findViewById(R.id.photoImageView) }
    //Uri들을 담을 리스트
    private val photoList = mutableListOf<Uri>()
    //타이머
    private var timer: Timer? = null
    //현재 인덱스값
    private var currentPosition = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo_frame)

        getPhotoUriFromIntent()
    }

    //넘어온 인텐트에서 Uri 추출하기
    private fun getPhotoUriFromIntent() {
        //일단 사이즈부터 가져오고
        val size = intent.getIntExtra("photoListSize",0)
        //그 사이즈만큼 반복하며 Uri값 복원
       for (i in 0..size){
            intent.getStringExtra("photo$i")?.let {
                photoList.add(Uri.parse(it))
            }
        }
    }

    //애니메이션 주면서 사진들 바꾸기
    private fun startTimer() {
        //5초 마다 반복
        timer = timer(period = 5 * 1000){
            //UI 작업이니까 유아이 쓰레드에서
            runOnUiThread {
                //현재와 다음위치 계산
                val currentIdx = currentPosition
                val nextIdx = if(currentPosition + 1 >= photoList.size) 0 else currentPosition + 1

                //이미지 넣기
                backgroundPhotoImageView.setImageURI(photoList[currentIdx])
                //다음 이미지는 애니메이션 효과
                photoImageView.alpha = 0f
                photoImageView.setImageURI(photoList[nextIdx])
                photoImageView.animate()
                    .alpha(1.0f)
                    .setDuration(1000)
                    .start()

                //인덱스 갱신
                currentPosition = nextIdx
            }
        }
    }

    override fun onStop() {
        super.onStop()
        timer?.cancel()
    }

    override fun onStart() {
        super.onStart()
        startTimer()
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }

}