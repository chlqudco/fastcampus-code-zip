package com.chlqudco.develop.electronicframe

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val addPhotoButton: Button by lazy { findViewById(R.id.addPhotoButton) }
    private val startPhotoFrameModeButton: Button by lazy { findViewById(R.id.startPhotoFrameModeButton) }
    private val imageViewList : List<ImageView> by lazy { mutableListOf<ImageView>().apply {
        add(findViewById(R.id.imageView11))
        add(findViewById(R.id.imageView12))
        add(findViewById(R.id.imageView13))
        add(findViewById(R.id.imageView21))
        add(findViewById(R.id.imageView22))
        add(findViewById(R.id.imageView23))
    } }

    private val imageUriList : MutableList<Uri> = mutableListOf()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initAddPhotoButton()
        initStartPhotoFrameModeButton()
    }

    private fun initAddPhotoButton() {
        addPhotoButton.setOnClickListener {
            //권한 획득 상태에 따른 클릭이벤트 처리
            when {
                //case 1. 이미 권한이 있는 경우
                ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED -> {
                    //바로 원하는 행동 실행
                    navigatePhotos()
                }
                //case 2. 거절한 이력이 있어서 교육용 팝업을 띄워야 하는 경우
                shouldShowRequestPermissionRationale(android.Manifest.permission.READ_EXTERNAL_STORAGE) -> {
                    //교육용 팝업 띄우기 함수
                    showPermissionContextPopup()
                }
                //case 3. 이도 저도 아니면 바로 권한 요청 팝업 띄우기
                else -> {
                    requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1000)
                }
            }
        }
    }


    private fun initStartPhotoFrameModeButton() {
        startPhotoFrameModeButton.setOnClickListener {
            val intent = Intent(this,PhotoFrameActivity::class.java)
            imageUriList.forEachIndexed { index, uri ->
                intent.putExtra("photo$index", uri.toString())
            }
            intent.putExtra("photoListSize",imageUriList.size)
            startActivity(intent)
        }
    }

    //사진 인텐트에서 받아온 값 처리
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        //예외처리 1. 제대로 받지 못한경우
        if(resultCode != Activity.RESULT_OK){
            return
        }

        //우리가 사진인텐트에 요청한 코드인지
        when(requestCode){
            2000->{
                //Uri값 저장
                val selectedImageUri : Uri? = data?.data

                //예외처리 2. Uri가 null일 경우 == 제대로 가져오지 못한 경우
                if (selectedImageUri != null){
                    //예외처리 3. 이미 6개가 꽉찬 경우
                    if(imageUriList.size == 6){
                        Toast.makeText(this,"더이상 넣을 수 없습니다",Toast.LENGTH_SHORT).show()
                        return
                    }
                    //UriList에 추가
                    imageUriList.add(selectedImageUri)
                    //뷰에 추가
                    imageViewList[imageUriList.size-1].setImageURI(selectedImageUri)
                }
                else{
                    Toast.makeText(this,"사진을 가져오지 못했습니다",Toast.LENGTH_SHORT).show()
                }
            }
            else->{
                Toast.makeText(this,"사진을 가져오지 못했습니다",Toast.LENGTH_SHORT).show()
            }
        }
    }
    //권한 결과
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        //requestCode에 따라 분기
        when (requestCode){
            //우리가 요청한 1000이면
            1000 -> {
                //권한 부여 했으면
                if(grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    //사진 가지러 가지
                    navigatePhotos()
                }
                //권한 없으면 꺼지기
                else{
                   Toast.makeText(this,"권한을 거부했어",Toast.LENGTH_SHORT).show()
                }
            }
            //1000번이 아닌건 알빠가 아님
            else -> { }
        }
    }

    //사진 보러 가는 함수
    private fun navigatePhotos() {
        //intent로 컨텐츠 프로바이더 이용, SAF인가?
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        //이미지 파일만 주세용
        intent.type = "image/*"
        //실행
        startActivityForResult(intent,2000)
    }

    //AlertDialog를 이용한 교육용 팝업 띄우기
    private fun showPermissionContextPopup() {
        AlertDialog.Builder(this)
            .setTitle("권한 요청")
            .setMessage("사진을 불러오기 위해 권한이 필요합니다")
            .setPositiveButton("수락") { _, _ -> requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1000) }
            .setNegativeButton("그럼에도 불구하고 거절") { _, _ -> }
            .create()
            .show()
    }
}