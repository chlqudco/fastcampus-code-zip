package com.chlqudco.develop.webbrowserrrr

import android.annotation.SuppressLint
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.core.widget.ContentLoadingProgressBar
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    private val addressBar : EditText by lazy { findViewById(R.id.addressBar) }
    private val webView : WebView by lazy { findViewById(R.id.webView) }
    private val goHomeButton: ImageButton by lazy { findViewById(R.id.goHomeButton) }
    private val goBackButton: ImageButton by lazy { findViewById(R.id.goBackButton) }
    private val goForwardButton: ImageButton by lazy { findViewById(R.id.goForwardButton) }
    private val refreshLayout : SwipeRefreshLayout by lazy { findViewById(R.id.refreshLayout) }
    private val progressBar: ContentLoadingProgressBar by lazy { findViewById(R.id.progressBar) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        bindViews()
    }

    //뒤로가기 버튼 재정의
    override fun onBackPressed() {
        //뒤로갈 수 있다면 뒤로 가기
        if (webView.canGoBack()){
            webView.goBack()
        }
        //더이상 뒤로 못가면 앱 종료
        else{
            super.onBackPressed()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initViews() {
        webView.apply {
            //앱 바깥의 앱을 실행하지 않도록
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            //자바 스크립트 사용 허가
            settings.javaScriptEnabled = true
            //웹페이지 로드
            loadUrl(DEFAULT_URL)
        }
    }

    private fun bindViews() {
        //홈버튼 클릭시
        goHomeButton.setOnClickListener {
            //집 가기
            webView.loadUrl(DEFAULT_URL)
        }

        //뒤로가기 클릭시
        goBackButton.setOnClickListener {
            webView.goBack()
        }

        //앞으로 버튼 클릭시
        goForwardButton.setOnClickListener {
            webView.goForward()
        }


        //에디트텍스트의 확인 버튼? 을 눌렀을때 할 일
        addressBar.setOnEditorActionListener { v, actionId, event ->
            //액션 던인지 확인
            if (actionId==EditorInfo.IME_ACTION_DONE){
                //에디트 텍스트에서 url을 가져온후 이동
                val loadingUrl = v.text.toString()

                //url이 http로 시작하지 않으면 넣어주기
                if (URLUtil.isNetworkUrl(loadingUrl)) {
                    webView.loadUrl(loadingUrl)
                }
                else{
                    webView.loadUrl("http://$loadingUrl")
                }
            }
            //false 리턴
            return@setOnEditorActionListener false
        }

        //리프레시 레이아웃 리스너 등록
        refreshLayout.setOnRefreshListener {
            //웹페이지 리로드
           webView.reload()
        }
    }

    //웹 뷰 클라이언트에 기능을 더 넣기 위해 재정의
    inner class WebViewClient : android.webkit.WebViewClient(){

        //페이지 이동 시작하면
        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)

            //프로그래스바 나타내기
            progressBar.show()
        }

        //페이지 로딩이 끝날때
        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)

            //리프레싱 빙글빙글 멈춰
            refreshLayout.isRefreshing = false

            //프로그래스바 없애기
            progressBar.hide()

            //만약 뒤로 갈수 없으면 뒤로가기 버튼 없애기
            goBackButton.isEnabled = webView.canGoBack()
            //앞도 똑같
            goForwardButton.isEnabled = webView.canGoForward()

            //현재 주소를 에디트텍스트에 대입
            addressBar.setText(url)
        }
    }

    //웹크롬 클라이언트 재정의, 위와 동일
    inner class WebChromeClient : android.webkit.WebChromeClient(){

        //진행 상황에 맞게
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            super.onProgressChanged(view, newProgress)

            //프로그래스바 대입
            progressBar.progress = newProgress
        }
    }

    companion object{
        private const val DEFAULT_URL = "http://www.google.com"
    }
}