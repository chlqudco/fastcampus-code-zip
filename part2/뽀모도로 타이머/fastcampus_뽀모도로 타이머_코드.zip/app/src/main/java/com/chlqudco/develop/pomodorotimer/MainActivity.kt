package com.chlqudco.develop.pomodorotimer

import android.annotation.SuppressLint
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private val remainMinutesTextView: TextView by lazy { findViewById(R.id.remainMinutesTextView) }
    private val remainSecondsTextView: TextView by lazy { findViewById(R.id.remainSecondsTextView) }
    private val seekBar: SeekBar by lazy { findViewById(R.id.seekBar) }

    private var currentCountDownTimer: CountDownTimer? = null

    private val soundPool = SoundPool.Builder().build()

    private var tickingSoundId: Int? = null
    private var bellSoundId: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        initSoundPool()
    }

    override fun onResume() {
        super.onResume()
        soundPool.autoResume()
    }

    override fun onPause() {
        super.onPause()
        soundPool.autoPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()
    }



    private fun initViews() {
        //시크바에 리스너를 담
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            //프로그래스바가 바뀌었을 때 텍스트 업데이트
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                //유저가 바꾼건지 체크해야함
                if (fromUser) {
                    updateRemainTime(progress * 1000 * 60L)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                stopCountDown()
            }

            //손을 놓는 순간 타이머 작동해야 하므로 여기서 타이머 생성
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seekBar ?: return

                //0초로 설정할때는 시작하면 안됨
                if (seekBar.progress == 0) {
                    stopCountDown()
                } else {
                    startCountDown()
                }
            }
        })
    }

    private fun initSoundPool() {
        tickingSoundId = soundPool.load(this, R.raw.timer_ticking, 1)
        bellSoundId = soundPool.load(this, R.raw.timer_bell, 1)
    }

    //카운트다운 타이머를 만들고 반환
    private fun createCountDownTimer(initialMillis: Long): CountDownTimer {
        return object : CountDownTimer(initialMillis, 1000) {
            //1초마다 뭐할지
            override fun onTick(millisUntilFinished: Long) {
                //분과 초의 텍스트 변경
                updateRemainTime(millisUntilFinished)
                //시크바의 위치? 변경
                updateSeekBar(millisUntilFinished)
            }

            //다 끝나면 뭐할지
            override fun onFinish() {
                completeCountDown()
            }
        }
    }

    private fun startCountDown() {
        //카운트 다운 타이머 받아온뒤 시작
        currentCountDownTimer = createCountDownTimer((seekBar.progress * 1000 * 60).toLong())
        currentCountDownTimer?.start()

        //소리도 재생
        tickingSoundId?.let {
            soundPool.play(it, 1F, 1F, 0, -1, 1F)
        }
    }

    private fun stopCountDown() {
        currentCountDownTimer?.cancel()
        currentCountDownTimer = null

        soundPool.autoPause()
    }

    private fun completeCountDown() {
        //0초로 초기화해주면 되지용
        updateRemainTime(0)
        updateSeekBar(0)

        //재생하던 티킹은 멈추고 bell플레이
        soundPool.autoPause()
        bellSoundId?.let {
            soundPool.play(it, 1F, 1F, 0, 0, 1F)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateRemainTime(millisUntilFinished: Long) {
        //밀리세컨드 타입을 적절히 변환 시켜서 대입
        val remainSeconds = millisUntilFinished / 1000

        remainMinutesTextView.text = "%02d'".format(remainSeconds / 60)
        remainSecondsTextView.text = "%02d".format(remainSeconds % 60)
    }

    private fun updateSeekBar(millisUntilFinished: Long) {
        //시크바 재설정
        seekBar.progress = (millisUntilFinished / 1000 / 60).toInt()
    }

}