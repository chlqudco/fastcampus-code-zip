package com.chlqudco.develop.lottolotto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {

    val numberSet = mutableSetOf<Int>()

    val numberPicker: NumberPicker by lazy { findViewById(R.id.numberpicker) }
    val addButton: Button by lazy { findViewById(R.id.AddButton) }
    val resetButton: Button by lazy { findViewById(R.id.ResetButton) }
    val randomButton: Button by lazy { findViewById(R.id.RandomButton) }
    val textViewList: List<TextView> by lazy {
        mutableListOf<TextView>(
            findViewById(R.id.ball1),
            findViewById(R.id.ball2),
            findViewById(R.id.ball3),
            findViewById(R.id.ball4),
            findViewById(R.id.ball5),
            findViewById(R.id.ball6)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //넘버 피커 범위 조절
        numberPicker.minValue = 1
        numberPicker.maxValue = 45

        initAddButton()
        initResetButton()
        initRandomButon()
    }

    private fun initRandomButon(){
        randomButton.setOnClickListener {
            val numlist = GetRandomNumberList()
            numlist.forEachIndexed { index, number ->
                textViewList[index].text = number.toString()
                textViewList[index].isVisible = true
                setBallBackGround(number, textViewList[index])
            }
        }
    }

    private fun GetRandomNumberList(): List<Int>{
        var numList = mutableListOf<Int>().apply {
            for(i in 1..45){
                if(numberSet.contains(i)){
                    continue
                }
                add(i)
            }
        }
        numList.shuffle()

        val newList = numberSet.toList() + numList.subList(0, 6-numberSet.size)

        return newList.sorted()
    }

    private fun initResetButton(){
        resetButton.setOnClickListener {
            numberSet.clear()

            textViewList.forEach {
                it.isVisible = false
            }
        }
    }

    private fun initAddButton(){
        addButton.setOnClickListener {
            //클릭시 넘버피커 번호 추가
            val number = numberPicker.value

            if(numberSet.size == 6){
                Toast.makeText(this,"꽉 찼습니다", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if(numberSet.contains(number)){
                Toast.makeText(this,"이미 있는 번호입니다", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            numberSet.add(number)
            textViewList[numberSet.size-1].text = number.toString()
            textViewList[numberSet.size-1].isVisible = true
            setBallBackGround(number,textViewList[numberSet.size-1])
        }
    }

    private fun setBallBackGround(number:Int, textView: TextView){
        when(number){
            in 1..10 -> textView.background = ContextCompat.getDrawable(this, R.drawable.circle_yellow)
            in 11..20 -> textView.background = ContextCompat.getDrawable(this, R.drawable.circle_blue)
            in 21..30 -> textView.background = ContextCompat.getDrawable(this, R.drawable.circle_red)
            in 31..40 -> textView.background = ContextCompat.getDrawable(this, R.drawable.circle_green)
            else -> textView.background = ContextCompat.getDrawable(this, R.drawable.circle_gray)
        }
    }
}