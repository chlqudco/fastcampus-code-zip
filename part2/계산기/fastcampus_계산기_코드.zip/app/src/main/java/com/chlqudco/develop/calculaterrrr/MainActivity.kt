package com.chlqudco.develop.calculaterrrr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.room.Room
import androidx.room.RoomDatabase
import com.chlqudco.develop.calculaterrrr.model.History
import java.lang.NumberFormatException

class MainActivity : AppCompatActivity() {
    private val expressionTextView: TextView by lazy { findViewById(R.id.expressionTextView) }
    private val resultTextView: TextView by lazy { findViewById(R.id.resultTextView) }
    private val historyLayout: View by lazy { findViewById(R.id.historyLayout) }
    private val historyLinearLayout: LinearLayout by lazy { findViewById(R.id.historyLinearLayout) }

    //직전에 누른게 연산자 기호일 경우
    private var isOperator = false

    //문장에 이미 연산자가 있는 경우
    private var hasOperator = false

    //룸 디비
    lateinit var db : AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "historyDB"
        ).build()
    }

    //C 버튼 눌렀을 때
    fun clearButtonClicked(v: View) {
        //걍 초기화만 하면 됨
        isOperator = false
        hasOperator = false
        expressionTextView.text = ""
        resultTextView.text = ""
    }

    //= 버튼 눌렀을 때
    fun resultButtonClicked(v: View) {
        val expressionTexts = expressionTextView.text.split(" ")

        //예외처리 1. 연산자를 안넣은 경우
        if (expressionTextView.text.isEmpty() || expressionTexts.size == 1) {
            return
        }

        //예외처리 2. 두번째 값 안넣은 경우
        if (expressionTexts.size != 3 && hasOperator) {
            Toast.makeText(this, "아직 완성되지 않은 수식입니다", Toast.LENGTH_SHORT).show()
            return
        }

        //예외처리 3. 숫자로 안바뀌는 경우 (아마 안일어남)
        if (expressionTexts[0].isNumber().not() || expressionTexts[2].isNumber().not()) {
            Toast.makeText(this, "오류가 발생했습니다", Toast.LENGTH_SHORT).show()
            return
        }

        //DB에 기록하기 위해 백업해두기
        val expressionText = expressionTextView.text.toString()
        //결과값 받아오기
        val resultText = calculateExpression()

        //DB에 저장하기
        Thread(Runnable {
            db.historyDao().insertHistory(History(null,expressionText,resultText))
        }).start()

        //적절히 옮겨주고 초기화
        expressionTextView.text = resultText
        resultTextView.text = ""
        isOperator = false
        hasOperator = false
    }

    //이외 버튼 눌렀을 때
    fun buttonClicked(v: View) {
        when (v.id) {
            R.id.button0 -> numberButtonClicked("0")
            R.id.button1 -> numberButtonClicked("1")
            R.id.button2 -> numberButtonClicked("2")
            R.id.button3 -> numberButtonClicked("3")
            R.id.button4 -> numberButtonClicked("4")
            R.id.button5 -> numberButtonClicked("5")
            R.id.button6 -> numberButtonClicked("6")
            R.id.button7 -> numberButtonClicked("7")
            R.id.button8 -> numberButtonClicked("8")
            R.id.button9 -> numberButtonClicked("9")

            R.id.buttomModulo -> operatorButtonClicked("%")
            R.id.buttonPlus -> operatorButtonClicked("+")
            R.id.buttonMinus -> operatorButtonClicked("-")
            R.id.buttonMulti -> operatorButtonClicked("*")
            R.id.buttonDivider -> operatorButtonClicked("/")
        }
    }

    //숫자를 눌렀을 경우
    private fun numberButtonClicked(number: String) {
        //직전에 입력한게 연산자면 한칸 띄어
        if (isOperator) {
            expressionTextView.append(" ")
        }
        //무적건 숫자니까
        isOperator = false

        //텍스트 가져와서 뒤에 넣기
        val expressionText = expressionTextView.text.split(" ")

        //예외처리 1. 15자리가 넘어가지 않도록
        if (expressionText.isNotEmpty() && expressionText.last().length >= 15) {
            Toast.makeText(this, "15자리 넘어가지 말아오", Toast.LENGTH_SHORT).show()
            return
        }
        //예외처리 2. 맨앞에 0이 오면 추가X
        if (expressionText.last().isEmpty() && number == "0") {
            Toast.makeText(this, "0 시작 허용 안함", Toast.LENGTH_SHORT).show()
            return
        }

        //마지막으로 뒤에 붙이기
        expressionTextView.append(number)
        //결과 텍스트뷰에 추가하기
        resultTextView.text = calculateExpression()
    }

    //연산자를 눌렀을 경우
    private fun operatorButtonClicked(opertor: String) {
        //예외처리 1.아직 아무것도 입력 안한경우 무시
        if (expressionTextView.text.isEmpty()) {
            return
        }

        //경우에 따라 분기
        when {
            //직전에 입력한게 연산자면 교체
            isOperator -> {
                val text = expressionTextView.text.toString()
                expressionTextView.text = text.dropLast(1) + opertor
            }
            //이미 연산자가 있으면 안돼, 나 계산 못해 ㅠㅠ
            hasOperator -> {
                Toast.makeText(this, "연산자 아직 하나밖에 못씀 ㅈㅅㅈㅅ", Toast.LENGTH_SHORT).show()
                return
            }
            //다 아니면 붙여
            else -> {
                expressionTextView.append(" $opertor")
            }
        }

        //연산자 잘보이게 색깔 변경하기
        val ssb = SpannableStringBuilder(expressionTextView.text)
        ssb.setSpan(
            ForegroundColorSpan(getColor(R.color.green)),
            expressionTextView.text.length - 1,
            expressionTextView.text.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        expressionTextView.text = ssb

        //방금 연산자 썻고 이젠 들어가니가
        isOperator = true
        hasOperator = true
    }

    //계산 결과값 반환해주는 함수
    private fun calculateExpression(): String {
        val expressionText = expressionTextView.text.split(" ")

        //예외 처리 1. 3개 입력 했는지
        if (hasOperator.not() || expressionText.size != 3) {
            return ""
        }
        //예외처리 2. 제대로 숫자로 변환?되는지 (애초에 있으면 안되는 함수)
        else if (expressionText[0].isNumber().not() || expressionText[2].isNumber().not()) {
            return ""
        }

        //각 항에 맞게 나눈뒤
        val exp1 = expressionText[0].toBigInteger()
        val exp2 = expressionText[2].toBigInteger()
        val op = expressionText[1]

        //연산자에 따른 연산 후 반환
        return when (op) {
            "+" -> (exp1 + exp2).toString()
            "-" -> (exp1 - exp2).toString()
            "*" -> (exp1 * exp2).toString()
            "/" -> (exp1 / exp2).toString()
            "%" -> (exp1 % exp2).toString()
            else -> ""
        }
    }

    //기록 버튼 눌렀을 때
    fun historyButtonClicked(v: View) {
        //뷰를 먼저 보인다
        historyLayout.isVisible = true

        //깨끗이 정리 한다
        historyLinearLayout.removeAllViews()

        //DB기록들 불러온다
        Thread(Runnable {
            db.historyDao().getAll().reversed().forEach {
                runOnUiThread {
                    val historyView = LayoutInflater.from(this).inflate(R.layout.history_row, null, false)
                    historyView.findViewById<TextView>(R.id.expressionTextView).text = it.expression
                    historyView.findViewById<TextView>(R.id.resultTextView).text = "= ${it.result}"

                    historyLinearLayout.addView(historyView)
                }
            }
        }).start()
    }

    //정상적으로 바뀌는지 확장함수 등록록
    fun String.isNumber(): Boolean {
        return try {
            this.toBigInteger()
            true
        } catch (e: NumberFormatException) {
            false
        }
    }

    //기록 닫기 버튼 눌렀을 때
    fun closeHistoryButtonClicked(v: View) {
        //걍 뷰 닫으면 끝
        historyLayout.isVisible = false
    }

    //기록 삭제 버튼
    fun historyClearButtonClicked(v: View) {
        historyLinearLayout.removeAllViews()

        Thread(Runnable {
            db.historyDao().deleteAll()
        }).start()

    }

}