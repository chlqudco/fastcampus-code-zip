package com.chlqudco.develop.secretdiaryyyy

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.EditText
import androidx.core.content.edit
import androidx.core.widget.addTextChangedListener

class NoteActivity : AppCompatActivity() {
    private val noteEditText: EditText by lazy { findViewById(R.id.noteEditText) }

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note)

        //프리퍼런스에서 저장된값 불러오기
        val noteSharedPreferences: SharedPreferences = getSharedPreferences("note", MODE_PRIVATE)
        noteEditText.setText(noteSharedPreferences.getString("note", ""))

        //러너블 객체로 할 일 지정
        val runnable = Runnable {
            getSharedPreferences("note", MODE_PRIVATE).edit {
                putString("note",noteEditText.text.toString())
            }
        }

        //쓴 값이 변경될때 마다 핸들러로 저장
        noteEditText.addTextChangedListener {
            handler.removeCallbacks(runnable)
            handler.postDelayed(runnable,500)
        }
    }
}
