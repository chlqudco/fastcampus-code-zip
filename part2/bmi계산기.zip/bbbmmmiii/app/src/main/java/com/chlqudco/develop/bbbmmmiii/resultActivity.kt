package com.chlqudco.develop.bbbmmmiii

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class resultActivity : AppCompatActivity() {

    val resultValueTextView : TextView by lazy {
        findViewById(R.id.resultValueTextView)
    }

    val resultStrTextView : TextView  by lazy {
        findViewById(R.id.resultStrTextView)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val weight = intent.getIntExtra("weight",0)
        val height = intent.getIntExtra("height",0)

        val result = weight / ((height/100.0) * (height/100.0))

        resultValueTextView.text = result.toString()

        resultStrTextView.text = when{
            result >= 35.0 -> "고도 비만"
            result >= 30.0 -> "중도 비만"
            result >= 25.0 -> "경도 비만"
            result >= 23.0 -> "과체중"
            result >= 18.5 -> "정상 체중"
            else -> "저제충"
        }

    }

}