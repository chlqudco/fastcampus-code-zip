package com.chlqudco.develop.secretdiaryyyy

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Debug
import android.util.Log
import android.widget.Button
import android.widget.NumberPicker
import androidx.appcompat.app.AlertDialog
import androidx.core.content.edit

class MainActivity : AppCompatActivity() {
    private val openButton: Button by lazy { findViewById(R.id.openButton) }
    private val changeButton : Button by lazy { findViewById(R.id.changeButton) }
    private val numberPicker1 : NumberPicker by lazy {
        findViewById<NumberPicker>(R.id.numberPicker1).apply {
            this.minValue = 0
            this.maxValue = 9
        }
    }
    private val numberPicker2 : NumberPicker by lazy {
        findViewById<NumberPicker>(R.id.numberPicker2).apply {
            this.minValue = 0
            this.maxValue = 9
        }
    }
    private val numberPicker3 : NumberPicker by lazy {
        findViewById<NumberPicker>(R.id.numberPicker3).apply {
            this.minValue = 0
            this.maxValue = 9
        }
    }

    private val passwordPreferences : SharedPreferences by lazy { getSharedPreferences("password", MODE_PRIVATE)}

    //비밀번호 변경 모드 인지
    private var isChanging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //넘버 피커들 초기화
        initNumberPickers()

        //오픈 버튼 초기화
        initOpenButton()

        //비밀번호 변경 버튼 초기화
        initChangeButton()
    }

    private fun initNumberPickers(){
        numberPicker1
        numberPicker2
        numberPicker3
    }

    private fun initOpenButton(){
        openButton.setOnClickListener {
            //예외 처리 1 : 비밀번호 변경 모드 인 경우
            if (isChanging){
                ShowAlertDialog("비밀번호 변경 중 입니다")
                return@setOnClickListener
            }
            //내가 입력한 비밀번호 불러오기
            val userPassword = "${numberPicker1.value}${numberPicker2.value}${numberPicker3.value}"
            //저장된 비밀번호 불러오기
            val storedPassword = passwordPreferences.getString("password","000")

            //두 비밀번호가 같다면 노트액티비티 실행
            if (userPassword.equals(storedPassword)){
                val intent = Intent(this,NoteActivity::class.java)
                startActivity(intent)
                finish()
            }
            else{
                ShowAlertDialog("비밀번호가 다릅니다")
                return@setOnClickListener
            }
        }
    }

    private fun initChangeButton(){
        changeButton.setOnClickListener {
            //변경 중 이었던 경우
            if (isChanging){
                //기본 설정
                isChanging = false
                changeButton.setBackgroundColor(Color.BLACK)

                //새로 설정한 값 셰어드 프리에 저장
                val userPassword : String = "${numberPicker1.value}${numberPicker2.value}${numberPicker3.value}"
                passwordPreferences.edit(true) {
                    putString("password",userPassword)
                }
            }
            //변경하려고 누르는 경우
            else{
                //비밀번호가 맞는지부터 확인
                val userPassword = "${numberPicker1.value}${numberPicker2.value}${numberPicker3.value}"
                val storedPassword = passwordPreferences.getString("password","000")
                if (userPassword.equals(storedPassword).not()){
                    ShowAlertDialog("비밀번호가 다릅니다")
                    return@setOnClickListener
                }

                //기본 설정
                isChanging = true
                changeButton.setBackgroundColor(Color.RED)
            }
        }
    }

    private fun ShowAlertDialog(message : String){
        AlertDialog.Builder(this)
            .setTitle("Warning")
            .setMessage(message)
            .setPositiveButton("확인",{ _ , _ ->})
            .create()
            .show()
    }
}