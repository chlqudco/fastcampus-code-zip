package com.chlqudco.develop.recorderrrrrrrrrrrrrrrrrrr

import android.annotation.SuppressLint
import android.content.Context
import android.os.SystemClock
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

//그 녹음버튼 위에 째깍째깍 거리는거 커스텀
class CountUpView(context: Context, attrs: AttributeSet? = null) : AppCompatTextView(context, attrs) {

    //시작은 당연히 0초
    private var startTimeStamp: Long = 0L

    //쓰레드로 시간 재면서 거시기 하기
    private val countUpAction: Runnable = object : Runnable {
        override fun run() {
            //현재 시간 저장
            val currentTimeStamp = SystemClock.elapsedRealtime()
            val countTimeSeconds = ((currentTimeStamp - startTimeStamp) / 1000L).toInt()
            updateCountTime(countTimeSeconds)

            handler?.postDelayed(this, 1000L)
        }
    }

    //째깍째깍 시작
    fun startCountUp() {
        //지금 시간 저장
        startTimeStamp = SystemClock.elapsedRealtime()
        handler?.post(countUpAction)
    }

    //끝났으면 얘도 멈춰
    fun stopCountUp() {
        handler?.removeCallbacks(countUpAction)
    }

    //지워버리기
    fun clearCountTime() {
        updateCountTime(0)
    }

    //현재까지 센 초로 텍스트 값 설정
    @SuppressLint("SetTextI18n")
    private fun updateCountTime(countTimeSeconds: Int) {
        val minutes = countTimeSeconds / 60
        val seconds = countTimeSeconds % 60

        text = "%02d:%02d".format(minutes, seconds)
    }
}
