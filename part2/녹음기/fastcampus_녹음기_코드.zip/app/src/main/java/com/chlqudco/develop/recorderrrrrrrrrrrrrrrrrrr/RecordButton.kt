package com.chlqudco.develop.recorderrrrrrrrrrrrrrrrrrr

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageButton

//커스텀 버튼
class RecordButton(context: Context, attrs : AttributeSet) : AppCompatImageButton(context, attrs) {
    //둥근 모양의 drawable 파일로 초기화
    init {
        setBackgroundResource(R.drawable.shape_oval_button)
    }

    //상태에 따라 어떤 아이콘을 세팅할지
    fun updateIconWithState(state: State){
        when(state){
            State.BEFORE_RECORDING -> {
                setImageResource(R.drawable.ic_record)
            }
            State.ON_RECORDING -> {
                setImageResource(R.drawable.ic_stop)
            }
            State.AFTER_RECORDING -> {
                setImageResource(R.drawable.ic_play)
            }
            State.ON_PLAYING -> {
                setImageResource(R.drawable.ic_stop)
            }
        }
    }
}