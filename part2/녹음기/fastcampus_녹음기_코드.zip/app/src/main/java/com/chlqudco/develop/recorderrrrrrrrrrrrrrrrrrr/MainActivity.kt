package com.chlqudco.develop.recorderrrrrrrrrrrrrrrrrrr

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    private val soundVisualizerView: SoundVisualizerView by lazy { findViewById(R.id.soundVisualizerView) }
    private val recordTimeTextView: CountUpView by lazy { findViewById(R.id.recordTimeTextView) }
    private val resetButton : Button by lazy { findViewById(R.id.resetButton) }
    private val recordButton : RecordButton by lazy { findViewById(R.id.recordButton) }

    //상태값 관리하기 위한 변수
    private var state = State.BEFORE_RECORDING
        set(value) {
            field = value
            //언제 누르지 못하게 할건지
            resetButton.isEnabled = (value == State.AFTER_RECORDING) || (value == State.ON_PLAYING)
            //상태에 따라 아이콘 업데이트
            recordButton.updateIconWithState(value)
        }

    //녹음과 재생을 위한 변수들
    private var recorder : MediaRecorder? = null
    private var player: MediaPlayer? = null

    //외부저장소 사용을 위한 저장소경로 저장
    private val recordingFilePath: String by lazy { "${externalCacheDir?.absolutePath}/recording.3gp" }

    //어떤 권한 요청할건지
    private val requiredPermissions = arrayOf(Manifest.permission.RECORD_AUDIO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestAudioPermission()
        initViews()
        bindViews()
    }

    private fun initViews() {
        //실행 초기 상태 업데이트
        state = State.BEFORE_RECORDING
        recordButton.updateIconWithState(state)
    }

    private fun bindViews(){
        soundVisualizerView.onRequestCurrentAmplitude = {
            recorder?.maxAmplitude ?: 0
        }

        resetButton.setOnClickListener {
            //재생 멈춰! 첫 상태로 복귀!
            stopPlaying()
            soundVisualizerView.clearVisualization()
            recordTimeTextView.clearCountTime()
            state = State.BEFORE_RECORDING
        }

        recordButton.setOnClickListener {
            //상태에 따라 하고싶은거 하러 가
            when(state){
                State.BEFORE_RECORDING -> { startRecording() }
                State.ON_RECORDING -> { stopRecording() }
                State.AFTER_RECORDING -> { startPlaying() }
                State.ON_PLAYING -> { stopPlaying() }
            }
        }
    }

    //앱 실행시 오디오 권한을 얻어오기 위한 함수
    private fun requestAudioPermission(){
        //권한 요청
        requestPermissions(requiredPermissions, REQUEST_RECORD_AUDIO_PERMISSION)
    }

    //권한 잘 받았냐
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        //잘 받아왔냐?
        val audioRecordPermissionGranted = requestCode == REQUEST_RECORD_AUDIO_PERMISSION && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED

        //만약 잘 못받아 왔으면
        if (!audioRecordPermissionGranted) {
            //교육용 함수 안보여 줬으면
            if (!shouldShowRequestPermissionRationale(permissions.first())) {
                //보여 드려
                showPermissionExplanationDialog()
            }
            //그것도 아니면 걍 꺼
            else {
                finish()
            }
        }
    }

    private fun startRecording(){
        //녹음기 초기설정 해주고
        recorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
            setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            setOutputFile(recordingFilePath)
            prepare()
        }
        //녹음 시작!
        recorder?.start()
        soundVisualizerView.startVisualizing(false)
        recordTimeTextView.startCountUp()
        state = State.ON_RECORDING
    }

    private fun stopRecording(){
        //녹음 중이던거 끄고 버려
        recorder?.run {
            stop()
            release()
        }
        recorder = null
        soundVisualizerView.stopVisualizing()
        recordTimeTextView.stopCountUp()
        state = State.AFTER_RECORDING
    }

    private fun startPlaying(){
        //녹음한거 들기 위한 초기설정
        player = MediaPlayer().apply {
            setDataSource(recordingFilePath)
            prepare()
        }
        //재생 다 끝나면 상태? 돌리기
        player?.setOnCompletionListener {
            stopPlaying()
            state = State.AFTER_RECORDING
        }
        //재생 시작!
        player?.start()
        soundVisualizerView.startVisualizing(true)
        recordTimeTextView.startCountUp()
        state = State.ON_PLAYING
    }

    private fun stopPlaying(){
        //재생 멈추려면 다버려
        player?.release()
        player = null
        soundVisualizerView.stopVisualizing()
        recordTimeTextView.stopCountUp()
        state = State.AFTER_RECORDING
    }

    private fun showPermissionExplanationDialog() {
        //교육용 다이얼로그 팟!
        AlertDialog.Builder(this)
            .setMessage("녹음기 인데 녹음권한 안주는건 무슨 심보임?")
            .setPositiveButton("권한 변경하러 가기") { _, _ -> navigateToAppSetting() }
            .setNegativeButton("앱 종료하기") { _, _ -> finish() }
            .show()
    }

    //앱 환경설정으로 고!
    private fun navigateToAppSetting() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri: Uri = Uri.fromParts("package", packageName, null)
        intent.data = uri
        startActivity(intent)
    }

    //상수 관리
    companion object{
        private const val REQUEST_RECORD_AUDIO_PERMISSION = 201
    }
}