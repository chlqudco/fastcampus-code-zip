package com.chlqudco.develop.recorderrrrrrrrrrrrrrrrrrr

//녹음 상태 관리를 위한 상수 클래스 서넌
enum class State {
    BEFORE_RECORDING,
    ON_RECORDING,
    AFTER_RECORDING,
    ON_PLAYING
}