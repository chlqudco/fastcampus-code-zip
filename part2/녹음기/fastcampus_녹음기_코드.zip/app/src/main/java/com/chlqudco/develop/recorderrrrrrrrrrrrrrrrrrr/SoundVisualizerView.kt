package com.chlqudco.develop.recorderrrrrrrrrrrrrrrrrrr

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

//말 소리에 따라 뷰가 나올껴
class SoundVisualizerView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    //볼륨값 가져오기 위한 변수
    var onRequestCurrentAmplitude: (() -> Int)? = null

    //페인트를 먼저 생성해야함, 어떻게 그릴지 정의
    private val amplitudePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.purple_500)
        strokeWidth = LINE_WIDTH
        strokeCap = Paint.Cap.ROUND
    }

    //그릴 사이즈
    private var drawingWidth: Int = 0
    private var drawingHeight: Int = 0

    //녹음의 볼륨값들 저장
    private var drawingAmplitudes: List<Int> = emptyList()

    private var isReplaying: Boolean = false
    private var replayingPosition: Int = 0

    //반복적으로 그리기 위해
    private val visualizeRepeatAction: Runnable = object : Runnable {
        override fun run() {
            if (!isReplaying) {
                val currentAmplitude = onRequestCurrentAmplitude?.invoke() ?: 0
                drawingAmplitudes = listOf(currentAmplitude) + drawingAmplitudes
            } else {
                replayingPosition++
            }
            invalidate()
            //20ms 마다 반복 실행
            handler?.postDelayed(this, ACTION_INTERVAL)
        }
    }

    //이걸로 그릴 영역을 알아냄...
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        drawingWidth = w
        drawingHeight = h
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        canvas ?: return

        //그릴 위치
        val centerY = drawingHeight / 2f
        var offsetX = drawingWidth.toFloat()

        drawingAmplitudes
            .let { amplitudes ->
                if (isReplaying) {
                    //가장 뒤에있는것부터 가져옴? 먼소리
                    amplitudes.takeLast(replayingPosition)
                } else {
                    amplitudes
                }
            }
            .forEach { amplitude ->
                //그릴 길이
                val lineLength = amplitude / MAX_AMPLITUDE * drawingHeight * 0.8F

                //다음 그릴 위치 지정
                offsetX -= LINE_SPACE
                //예외처리 1. 너무 많이 그리면 오버플로우 됨
                if (offsetX < 0) return@forEach

                //그리기
                canvas.drawLine(
                    offsetX,
                    centerY - lineLength / 2F,
                    offsetX,
                    centerY + lineLength / 2F,
                    amplitudePaint
                )
            }
    }

    fun startVisualizing(isReplaying: Boolean) {
        this.isReplaying = isReplaying
        handler?.post(visualizeRepeatAction)
    }

    fun stopVisualizing() {
        replayingPosition = 0
        handler?.removeCallbacks(visualizeRepeatAction)
    }

    fun clearVisualization() {
        drawingAmplitudes = emptyList()
        //뷰 갱신하는 함수
        invalidate()
    }

    //사각형 정보?
    companion object {
        private const val LINE_WIDTH = 10F
        private const val LINE_SPACE = 15F
        private const val MAX_AMPLITUDE = Short.MAX_VALUE.toFloat()
        private const val ACTION_INTERVAL = 20L
    }
}
