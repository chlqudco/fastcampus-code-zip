package com.chlqudco.develop.bbbmmmiii

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    val weightEditText : EditText by lazy {
        findViewById(R.id.weightEditTex)
    }

    val heightEditText : EditText by lazy {
        findViewById(R.id.heightEditText)
    }

    val resultButton : Button by lazy {
        findViewById(R.id.resultButton)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultButton.setOnClickListener {
            val intent = Intent(this, resultActivity::class.java)

            if(weightEditText.text.isEmpty() || heightEditText.text.isEmpty()){
                Toast.makeText(this,"그.. 입력 제대로 해주세요",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val weight = weightEditText.text.toString().toInt()
            val height = heightEditText.text.toString().toInt()

            intent.putExtra("weight",weight)
            intent.putExtra("height",height)

            startActivity(intent)
        }
    }
}