package com.chlqudco.develop.youtubeapp.dto

import com.chlqudco.develop.youtubeapp.model.VideoModel

data class VideoDto(
    val videos: List<VideoModel>
)
