package com.chlqudco.develop.findlocation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.view.isVisible
import com.chlqudco.develop.findlocation.databinding.ActivityMainBinding
import com.chlqudco.develop.findlocation.schema.entity.LocationLatLngEntity
import com.chlqudco.develop.findlocation.schema.entity.SearchResultEntity
import com.chlqudco.develop.findlocation.schema.response.search.Poi
import com.chlqudco.develop.findlocation.schema.response.search.Pois
import com.chlqudco.develop.findlocation.utillity.RetrofitUtil
import kotlinx.coroutines.*
import java.lang.Exception
import kotlin.coroutines.CoroutineContext

//POI(포인트 오브 인터레스트) = tmap에서 제공하는.. 라이브러리? API?

class MainActivity : AppCompatActivity(), CoroutineScope {

    //코루틴에서 이용
    private lateinit var job: Job

    //코루틴 상속받은거 구현
    override val coroutineContext: CoroutineContext
    //메인쓰레드에서 동작하도록
        get() = Dispatchers.Main + job

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: SearchRecyclerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        job = Job()

        initAdapter()
        initViews()
        bindViews()
        initData()
    }

    //단 한줄;
    private fun initAdapter() {
        adapter = SearchRecyclerAdapter()
    }

    //ㄹㅇ 초기화만 함
    private fun initViews() = with(binding) {
        //xml에서 안보이게 했으면서 왜 지랄?
        emptyResultTextView.isVisible = false
        recyclerView.adapter = adapter
    }

    //단 두줄;
    private fun bindViews() = with(binding) {
        searchButton.setOnClickListener {
            searchKeyword(searchBarInputView.text.toString())
        }
    }

    //데이터 초기화?? 뭐하는거야 도대체
    private fun initData() {
        adapter.notifyDataSetChanged()
    }

    //데이터 가져오기
    private fun setData(pois: Pois) {
        val dataList = pois.poi.map {
            SearchResultEntity(
                fullAdress = makeMainAdress(it),
                name = it.name ?: "",
                locationLatLng = LocationLatLngEntity(it.noorLat, it.noorLon)
            )
        }
        //어뎁터에 방금 만든 데이터와 리스너 넣어주기
        adapter.setSearchResultList(dataList) {
            startActivity(Intent(this, MapActivity::class.java).apply {
            putExtra(MapActivity.SEARCH_RESULT_EXTRA_KEY, it) }) }
    }

    //키워드를 기반으로 검색 실행
    private fun searchKeyword(keywordString: String) {
        //코루틴으로 돌면서
        launch(coroutineContext) {
            try {
                //검색 자체는 IO쓰레드로 전환
                withContext(Dispatchers.IO) {
                    //그... 검색 결과 가져오기
                    val response = RetrofitUtil.apiService.getSearchLocation(keyword = keywordString)
                    if (response.isSuccessful) {
                        val body = response.body()
                        //그.. 이건 메인쓰레드에서
                        withContext(Dispatchers.Main) {
                            Log.e("list", body.toString())
                            body?.let { searchResponseSchema ->
                                //바디에서 어거지로 poi들 꺼내가 데이터 세팅해라
                                setData(searchResponseSchema.searchPoiInfo.pois)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, "검색하는 과정에서 에러가 발생했습니다. : ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //그 뭐냐 건물 주소 제대로? 가져오는 함수, 주소 형식이 다 지 좆대로임
    private fun makeMainAdress(poi: Poi): String =
        //부번? 이 뭔데
        if (poi.secondNo?.trim().isNullOrEmpty()) {
            (poi.upperAddrName?.trim() ?: "") + " " + (poi.middleAddrName?.trim() ?: "") + " " + (poi.lowerAddrName?.trim() ?: "") + " " + (poi.detailAddrName?.trim() ?: "") + " " + poi.firstNo?.trim()
        } else {
            (poi.upperAddrName?.trim() ?: "") + " " + (poi.middleAddrName?.trim() ?: "") + " " + (poi.lowerAddrName?.trim() ?: "") + " " + (poi.detailAddrName?.trim() ?: "") + " " + (poi.firstNo?.trim() ?: "") + " " + poi.secondNo?.trim()
        }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
}