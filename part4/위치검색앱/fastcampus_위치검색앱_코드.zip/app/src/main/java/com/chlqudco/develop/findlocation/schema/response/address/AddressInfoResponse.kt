package com.chlqudco.develop.findlocation.schema.response.address

//내 정보 불러왕
data class AddressInfoResponse(
    val addressInfo: AddressInfo
)
