package com.chlqudco.develop.findlocation.schema.entity

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

//검색 결과에 필요한 자료들, 인텐트로 넘겨주기 위해 파써블???
@Parcelize
data class SearchResultEntity(
    val fullAdress: String,
    val name: String,
    val locationLatLng: LocationLatLngEntity
): Parcelable
