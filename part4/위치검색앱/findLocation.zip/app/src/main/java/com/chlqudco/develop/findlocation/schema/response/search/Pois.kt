package com.chlqudco.develop.findlocation.schema.response.search

data class Pois(
    val poi: List<Poi>
)
