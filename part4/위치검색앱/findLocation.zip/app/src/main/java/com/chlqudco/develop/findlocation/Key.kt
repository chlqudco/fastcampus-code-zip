package com.chlqudco.develop.findlocation

object Key {
    const val TMAP_API = "l7xxf0681ff39bce40a0a145331253f13e14"
}
