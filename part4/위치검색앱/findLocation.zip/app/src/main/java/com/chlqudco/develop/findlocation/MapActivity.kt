package com.chlqudco.develop.findlocation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chlqudco.develop.findlocation.databinding.ActivityMapBinding
import com.chlqudco.develop.findlocation.schema.entity.LocationLatLngEntity
import com.chlqudco.develop.findlocation.schema.entity.SearchResultEntity
import com.chlqudco.develop.findlocation.utillity.RetrofitUtil
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

class MapActivity : AppCompatActivity(), OnMapReadyCallback, CoroutineScope {

    private lateinit var binding: ActivityMapBinding
    //구골 맵
    private lateinit var map: GoogleMap
    private lateinit var searchResult: SearchResultEntity
    //위치 관리 매니저님
    private lateinit var locationManager: LocationManager
    private lateinit var myLocationListener: MyLocationListener

    //잡은 왜 필요한거임?
    private lateinit var job: Job

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main + job

    private var currentSelectMarker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        job = Job()

        //그.. 검색 결과로 넘어온 좌표 가져오기
        if (::searchResult.isInitialized.not()) {
            intent?.let {
                searchResult = intent.getParcelableExtra(SEARCH_RESULT_EXTRA_KEY) ?: throw Exception("데이터가 존재하지 않습니다.")
                setupGoogleMap()
            }
        }
        bindViews()
    }

    //현위치 버튼 리스너
    private fun bindViews() = with(binding) {
        currentLocationButton.setOnClickListener {
            getMyLocation()
        }
    }

    //프래그먼트에 그골 지도 불러오기
    private fun setupGoogleMap() {
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    //온 맵 레디 콜백을 위한 함수
    override fun onMapReady(map: GoogleMap) {
        //구골 맵 이식
        this.map = map

        //마커좀 찍어봐~
        currentSelectMarker = setupMarker(searchResult)

        //마커 화면에 나타내기
        currentSelectMarker?.showInfoWindow()
    }

    //마커 찍고 카메라도 이동
    private fun setupMarker(searchResult: SearchResultEntity): Marker {
        //마커 위치
        val positionLatLng = LatLng(
            searchResult.locationLatLng.latitude.toDouble(),
            searchResult.locationLatLng.longitude.toDouble()
        )
        //마커 속성
        val markerOption = MarkerOptions().apply {
            position(positionLatLng)
            title(searchResult.name)
            snippet(searchResult.fullAdress)
        }
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(positionLatLng, CAMERA_ZOOM_LEVEL))

        return map.addMarker(markerOption)
    }

    //내 현위치 불러오는 함수
    private fun getMyLocation() {
        //초기화 안했으면 초기화 하기.
        if (::locationManager.isInitialized.not()) {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        }
        //gps 켰냐?
        val isGpsEnable = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

        if (isGpsEnable) {
            //권한 받았냐?
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), PERMISSION_REQUEST_CODE)
            } else {
                //권한 다 받았으면 함수 실행
                setMyLocationListener()
            }
        }
    }

    //진짜 현위치 불러오는 서브스스
    @SuppressLint("MissingPermission")
    private fun setMyLocationListener() {
        //기다리는 최소 시간 및 최소 거리
        val minTime: Long = 1500
        val minDistance = 100f
        //초기화 해
        if (::myLocationListener.isInitialized.not()) {
            myLocationListener = MyLocationListener()
        }
        //매니저님이 실행해 줄거야
        with(locationManager) {
            //현재 내 위치에 대한 정보로 업데이트 요청
            requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, myLocationListener)
            requestLocationUpdates(LocationManager.NETWORK_PROVIDER, minTime, minDistance, myLocationListener)
        }
    }

    //내 위치 바뀌었을 때 불리는 함수
    private fun onCurrentLocationChanged(locationEntity: LocationLatLngEntity) {
        //카메라로 쫒아가
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(locationEntity.latitude.toDouble(), locationEntity.longitude.toDouble()), CAMERA_ZOOM_LEVEL))
        //얘는 뭐지?
        loadReverseGeoInformation(locationEntity)
        //위 함수 때문에 리스너를 제거해야된다네?
        removeLocationListener()
    }

    //위치 정보로 위도경도 받아오는 함수?
    private fun loadReverseGeoInformation(locationEntity: LocationLatLngEntity) {
        launch(coroutineContext) {
            try {
                withContext(Dispatchers.IO) {
                    val response = RetrofitUtil.apiService.getReverseGeoCode(lat = locationEntity.latitude.toDouble(), lon = locationEntity.longitude.toDouble())
                    if (response.isSuccessful) {
                        val body = response.body()
                        withContext(Dispatchers.Main) {
                            Log.e("list", body.toString())
                            body?.let {
                                currentSelectMarker = setupMarker(SearchResultEntity(fullAdress = it.addressInfo.fullAddress ?: "", name = "내 위치", locationLatLng = locationEntity))
                                currentSelectMarker?.showInfoWindow()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MapActivity, "검색하는 과정에서 에러가 발생했습니다. : ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //뭐지? 내 위치 안불러와도 된다고?
    private fun removeLocationListener() {
        if (::locationManager.isInitialized && ::myLocationListener.isInitialized) {
            locationManager.removeUpdates(myLocationListener)
        }
    }

    //권한 결과값
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                setMyLocationListener()
            } else {
                Toast.makeText(this, "권한을 받지 못했습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //위치 리스너를 상속한 위치 리스너 클래스
    inner class MyLocationListener : LocationListener {
        //내 위치 바꼈으면 존나 추적해
        override fun onLocationChanged(location: Location) {
            val locationLatLngEntity = LocationLatLngEntity(
                location.latitude.toFloat(),
                location.longitude.toFloat()
            )
            //바뀐값으로 갱신하는 함수
            onCurrentLocationChanged(locationLatLngEntity)
        }
    }

    companion object {
        //검색 결과 키? 코드
        const val SEARCH_RESULT_EXTRA_KEY = "SearchResult"
        const val PERMISSION_REQUEST_CODE = 1
        const val CAMERA_ZOOM_LEVEL = 17f
    }

}
