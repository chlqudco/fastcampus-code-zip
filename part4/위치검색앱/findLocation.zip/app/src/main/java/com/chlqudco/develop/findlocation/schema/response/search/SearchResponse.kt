package com.chlqudco.develop.findlocation.schema.response.search

//세분화의 세분화의 세분화, 아주 개지랄
data class SearchResponse(
    val searchPoiInfo: SearchPoiInfo
)
