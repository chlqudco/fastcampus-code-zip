package com.chlqudco.develop.findlocation.schema.entity

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

//단지 위경도 값
@Parcelize
data class LocationLatLngEntity(
    val latitude: Float,
    val longitude: Float
): Parcelable

