package com.chlqudco.develop.findimage.data

import com.chlqudco.develop.findimage.data.models.PhotoResponse
import com.facebook.shimmer.BuildConfig
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface UnsplashApiService {

    //30개 갖다달라고 요청, 쿼리는 검색어
    @GET("photos/random?client_id=QCuIOFzS6lNOeBpUiMrpwM18pDF1tLHjriRJilmF0nM&count=30")
    suspend fun getRandomPhotos(
        @Query("query") query: String?
    ): Response<List<PhotoResponse>>
}
