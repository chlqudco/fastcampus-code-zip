package com.chlqudco.develop.findimage.data

//요청 base url
object Url {
    const val UNSPLASH_BASE_URL = "https://api.unsplash.com/"
}
