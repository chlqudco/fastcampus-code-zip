package com.chlqudco.develop.dust.data.models.airquality

import androidx.annotation.ColorRes
import com.chlqudco.develop.dust.R
import com.google.gson.annotations.SerializedName

//클래스 구조가 이해 안가는거는 문법이 모자란건가?
enum class Grade(
  val label: String,
  val emoji: String,
  @ColorRes val colorResId: Int
) {

  @SerializedName("1")
  GOOD("좋음", "😆", R.color.blue),

  @SerializedName("2")
  NORMAL("보통", "🙂", R.color.green),

  @SerializedName("3")
  BAD("나쁨", "😞", R.color.yellow),

  @SerializedName("4")
  AWFUL("매우 나쁨", "😫", R.color.red),

  UNKNOWN("미측정", "🧐", R.color.gray);

  //투스트링 재정의
  override fun toString(): String {
    return "$label $emoji"
  }
}
