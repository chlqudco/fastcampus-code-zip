package com.chlqudco.develop.dust.data

import androidx.viewbinding.BuildConfig
import com.chlqudco.develop.dust.data.models.airquality.MeasuredValue
import com.chlqudco.develop.dust.data.models.monitoringstation.MonitoringStation
import com.chlqudco.develop.dust.data.services.AirKoreaApiService
import com.chlqudco.develop.dust.data.services.KakaoLocalApiService
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

object Repository {

    //근처 그거 가져오기
    suspend fun getNearbyMonitoringStation(latitude: Double, longitude: Double): MonitoringStation? {
        //위경도를 tm좌표로 변환
        val tmCoordinates = kakaoLocalApiService
            .getTmCoordinates(longitude, latitude)
            .body()?.documents?.firstOrNull()

        val tmX = tmCoordinates?.x
        val tmY = tmCoordinates?.y

        //tm좌표를 가지고 근처의 측정소 가져오기
        return airKoreaApiService
            .getNearbyMonitoringStation(tmX!!, tmY!!)
            .body()?.response?.body?.monitoringStations?.minByOrNull { it.tm ?: Double.MAX_VALUE }
    }

    //근처 측정소 대기오염값 가져오기
    suspend fun getLatestAirQualityData(stationName: String): MeasuredValue? =
        airKoreaApiService
            .getRealtimeAirQualties(stationName)
            .body()?.response?.body?.measuredValues?.firstOrNull()

    //카카오 api용 레트로핏 만드리
    private val kakaoLocalApiService: KakaoLocalApiService by lazy {
        Retrofit.Builder()
            .baseUrl(Url.KAKAO_API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(buildHttpClient())
            .build()
            .create()
    }

    //에어코리아 api용 레트로핏 만드리
    private val airKoreaApiService: AirKoreaApiService by lazy {
        Retrofit.Builder()
            .baseUrl(Url.AIR_KOREA_API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(buildHttpClient())
            .build()
            .create()
    }

    //로깅을 위한 클라이언트, 아예 이해 못함
    private fun buildHttpClient(): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = if(BuildConfig.DEBUG) {
                        HttpLoggingInterceptor.Level.BODY
                    } else {
                        HttpLoggingInterceptor.Level.NONE
                    }
                }
            )
            .build()
}
