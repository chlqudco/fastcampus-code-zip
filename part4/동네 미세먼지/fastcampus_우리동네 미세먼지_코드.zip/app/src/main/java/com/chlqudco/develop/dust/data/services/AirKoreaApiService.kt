package com.chlqudco.develop.dust.data.services

import androidx.viewbinding.BuildConfig
import com.chlqudco.develop.dust.data.models.airquality.AirQualityResponse
import com.chlqudco.develop.dust.data.models.monitoringstation.MonitoringStationsResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

//에어코리아 API 활용 함수
interface AirKoreaApiService {

    //근처 측정소 가져오는 API호출
    @GET("B552584/MsrstnInfoInqireSvc/getNearbyMsrstnList?serviceKey=jINaTJi2t47BtAgvdTln9PsdcRANCLVtmGikSX6c1lv3xb%2B0Cvoc8iePL0kJK8DO6%2FX6SBh%2BCg%2B64wepQ2wZvg%3D%3D&returnType=json")
    suspend fun getNearbyMonitoringStation(
        @Query("tmX") tmX: Double,
        @Query("tmY") tmY: Double
    ): Response<MonitoringStationsResponse>

    //공기 질 가져오는 호출
    @GET("B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty" +
        "?serviceKey=jINaTJi2t47BtAgvdTln9PsdcRANCLVtmGikSX6c1lv3xb%2B0Cvoc8iePL0kJK8DO6%2FX6SBh%2BCg%2B64wepQ2wZvg%3D%3D" +
        "&returnType=json" +
        "&dataTerm=DAILY" +
        "&ver=1.3")
    suspend fun getRealtimeAirQualties(
        @Query("stationName") stationName: String
    ): Response<AirQualityResponse>
}
