package com.chlqudco.develop.dust.data.services

import com.chlqudco.develop.dust.data.models.tmcoordinates.TmCoordinatesResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

//카카오 API 이용 인터페이스
interface KakaoLocalApiService {

    @Headers("Authorization: KakaoAK bc2b3af3db79e0ac2dc02d73a083a1c0")
    @GET("v2/local/geo/transcoord.json?output_coord=TM")
    suspend fun getTmCoordinates(
        @Query("x") longitude: Double,
        @Query("y") latitude: Double
    ): Response<TmCoordinatesResponse>
}
