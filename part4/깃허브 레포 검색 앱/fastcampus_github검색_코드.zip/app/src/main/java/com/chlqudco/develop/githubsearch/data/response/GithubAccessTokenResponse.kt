package com.chlqudco.develop.githubsearch.data.response

class GithubAccessTokenResponse(
    val accessToken: String,
    val scope: String,
    val tokenType: String
)
