package com.chlqudco.develop.githubsearch.data

object Url {

    const val GITHUB_URL = "https://github.com"

    const val GITHUB_API_URL = "https://api.github.com"

}
