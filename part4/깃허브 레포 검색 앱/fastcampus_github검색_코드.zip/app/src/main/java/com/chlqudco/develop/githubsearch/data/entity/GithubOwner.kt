package com.chlqudco.develop.githubsearch.data.entity

data class GithubOwner(
    val login: String,
    val avatarUrl: String
)
