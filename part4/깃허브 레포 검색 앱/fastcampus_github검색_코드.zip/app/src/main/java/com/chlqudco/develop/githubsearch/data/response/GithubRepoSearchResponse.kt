package com.chlqudco.develop.githubsearch.data.response

import com.chlqudco.develop.githubsearch.data.entity.GithubRepoEntity

data class GithubRepoSearchResponse(
    val totalCount: Int,
    val items: List<GithubRepoEntity>
)
