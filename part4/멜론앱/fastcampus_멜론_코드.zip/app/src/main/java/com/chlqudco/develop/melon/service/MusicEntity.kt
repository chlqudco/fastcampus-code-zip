package com.chlqudco.develop.melon.service

import com.google.gson.annotations.SerializedName

//시리얼라이즈드네임 어노테이션 : 서버에서 내려주는 키? 랑 맞춰주기 위한 쓸데없는 작업

//음악에 뭐가 들어가니?
data class MusicEntity(
    //제목
    @SerializedName("track") val track: String,
    //음악 주소
    @SerializedName("streamUrl") val streamUrl: String,
    //가수
    @SerializedName("artist") val artist: String,
    //커버 이미지 주소
    @SerializedName("cover") val coverUrl: String
)