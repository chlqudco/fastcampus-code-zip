package com.chlqudco.develop.melon

//으막 재생?에 관한 모든 정보??들을 모델 클래스로 관리
data class PlayerModel(
    //갖고 있는 음악들
    private val playMusicList: List<MusicModel> = emptyList(),
    //몇번째 음악을 재생하는지
    var currentPosition: Int = -1,
    //재생화면 보고 있냐
    var isWatchingPlayListView: Boolean = true
) {

    //isPlaying을 위해 모델 새로 반환
    fun getAdapterModels(): List<MusicModel> {
        return playMusicList.mapIndexed { index, musicModel ->
            val newItem = musicModel.copy(
                isPlaying = index == currentPosition
            )
            newItem
        }
    }

    //뭐 선택했는지 알아맞춰 보세요
    fun updateCurrentPosition(musicModel: MusicModel) {
        currentPosition = playMusicList.indexOf(musicModel)
    }

    //다음 곡 가져오기
    fun nextMusic(): MusicModel? {
        if (playMusicList.isEmpty()) return null

        //마지막이면 0으로 빙빙 돌아가는 회전목마
        currentPosition = if ((currentPosition + 1) == playMusicList.size) 0 else currentPosition + 1
        return playMusicList[currentPosition]
    }

    //이전곡 가져오기
    fun prevMusic(): MusicModel? {
        if (playMusicList.isEmpty()) return null

        currentPosition = if ((currentPosition - 1) < 0) playMusicList.lastIndex else currentPosition - 1

        return playMusicList[currentPosition]
    }

    //지금 재생하고 있는거 가져오기
    fun currentMusicModel(): MusicModel? {
        if (playMusicList.isEmpty()) return null

        return playMusicList[currentPosition]
    }

}