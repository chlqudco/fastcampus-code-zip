package com.chlqudco.develop.melon

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


//ExoPlayer 을 이용한 음악 재생 앱
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //메인 액티비티에 바로 프래그먼트 부착
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, PlayerFragment.newInstance())
            .commit()
    }
}