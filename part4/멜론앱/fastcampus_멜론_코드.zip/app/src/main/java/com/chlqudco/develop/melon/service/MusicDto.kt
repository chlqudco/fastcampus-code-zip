package com.chlqudco.develop.melon.service

//걍 디티오임;
data class MusicDto(
    val musics: List<MusicEntity>
)