package com.chlqudco.develop.melon

import com.chlqudco.develop.melon.service.MusicDto
import com.chlqudco.develop.melon.service.MusicEntity

//서버에서 내려주는 모델과 뷰에서 쓰는 모델이 다르게 구현, 그 둘을 연결시켜주는 친구

//서버에서 받은 뮤직엔티티를 뮤직모델 형식으로 변환
fun MusicEntity.mapper(id: Long): MusicModel =
    MusicModel(
        id = id,
        streamUrl = streamUrl,
        coverUrl = coverUrl,
        track = track,
        artist = artist
    )

//Dto를 모델로 바꿔줌
fun MusicDto.mapper(): PlayerModel =
    PlayerModel(
        playMusicList = musics.mapIndexed { index, musicEntity ->
                musicEntity.mapper(index.toLong()) }
    )