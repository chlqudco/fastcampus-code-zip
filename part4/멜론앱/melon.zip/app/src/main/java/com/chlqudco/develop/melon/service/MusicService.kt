package com.chlqudco.develop.melon.service

import retrofit2.Call
import retrofit2.http.GET

interface MusicService {

    //음악들 받아오는 함수
    @GET("/v3/9f853a2a-62b3-48f4-91d5-65eabd0b32f5")
    fun listMusics() : Call<MusicDto>
}