package com.chlqudco.develop.melon

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SeekBar
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.chlqudco.develop.melon.databinding.FragmentPlayerBinding
import com.chlqudco.develop.melon.service.MusicDto
import com.chlqudco.develop.melon.service.MusicService
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class PlayerFragment : Fragment(R.layout.fragment_player) {

    private var model: PlayerModel = PlayerModel()
    private var binding: FragmentPlayerBinding? = null
    private var player: SimpleExoPlayer? = null
    private lateinit var playListAdapter: PlayListAdapter

    private val updateSeekRunnable = Runnable {
        updateSeek()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fragmentPlayerBinding = FragmentPlayerBinding.bind(view)
        binding = fragmentPlayerBinding

        initPlayView(fragmentPlayerBinding)
        initPlayListButton(fragmentPlayerBinding)
        initPlayControlButtons(fragmentPlayerBinding)
        initSeekBar(fragmentPlayerBinding)
        initRecyclerView(fragmentPlayerBinding)


        getVideoListFromServer()
    }

    //시크바 초기화
    @SuppressLint("ClickableViewAccessibility")
    private fun initSeekBar(fragmentPlayerBinding: FragmentPlayerBinding) {
        //재생화면 식바 처리
        fragmentPlayerBinding.playerSeekBar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            //옮기다가 거기서 멈추면 거기서부터 노래 재생
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                player?.seekTo((seekBar.progress * 1000).toLong())
            }

        })
        //재생목록 시크바는 걍 터치 처리를 안함
        fragmentPlayerBinding.playListSeekBar.setOnTouchListener { _, _ ->
            false
        }
    }

    //재생, 이전버튼, 다음버튼 이벤트 구현
    private fun initPlayControlButtons(fragmentPlayerBinding: FragmentPlayerBinding) {

        fragmentPlayerBinding.playControlImageView.setOnClickListener {
            val player = this.player ?: return@setOnClickListener

            //상태에 따라 분기
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }

        }

        //다음 곡 재생
        fragmentPlayerBinding.skipNextImageView.setOnClickListener {
            val nextMusic = model.nextMusic() ?: return@setOnClickListener
            playMusic(nextMusic)
        }

        //이전 곡 재생
        fragmentPlayerBinding.skipPrevImageView.setOnClickListener {
            val prevMusic = model.prevMusic() ?: return@setOnClickListener
            playMusic(prevMusic)
        }
    }

    //재생 화면 초기화
    private fun initPlayView(fragmentPlayerBinding: FragmentPlayerBinding) {
        //엑소 플레이어 등록
        context?.let { player = SimpleExoPlayer.Builder(it).build() }
        fragmentPlayerBinding.playerView.player = player


        binding?.let { binding ->
            //엑소 플레이어 상태 변화에 따른 리스너
            player?.addListener(object: Player.EventListener {
                //재생, 일시정지 의 상태가 변화할 때 뭐 할래
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    super.onIsPlayingChanged(isPlaying)

                    //이미지 리소스 바꿀래래
                   if (isPlaying) {
                        binding.playControlImageView.setImageResource(R.drawable.ic_baseline_pause_48)
                    } else {
                        binding.playControlImageView.setImageResource(R.drawable.ic_baseline_play_arrow_24)
                    }
                }

                //state값을 반환함, 플레이어의 상태 반환
                override fun onPlaybackStateChanged(state: Int) {
                    super.onPlaybackStateChanged(state)
                    //그래서 왜 얘는 여기서 호출..?
                    updateSeek()
                }

                //노래가 바뀌면 얘가 불림
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    super.onMediaItemTransition(mediaItem, reason)

                    //정보 갱신
                    val newIndex = mediaItem?.mediaId ?: return
                    model.currentPosition = newIndex.toInt()
                    updatePlayerView(model.currentMusicModel())
                    //어댑터에 바뀐거 보내줌
                    playListAdapter.submitList(model.getAdapterModels())
                }
            })
        }
    }

    //싴바 업데이트 로직
    private fun updateSeek() {
        val player = this.player ?: return

        //몇초 재생함?
        val duration = if (player.duration >= 0) player.duration else 0
        val position = player.currentPosition

        updateSeekUi(duration, position)

        val state = player.playbackState

        //재생 중이면 1초마다 업데이트 반복 호출
        view?.removeCallbacks(updateSeekRunnable)
        if (state != Player.STATE_IDLE && state != Player.STATE_ENDED) {
            view?.postDelayed(updateSeekRunnable, 1000)
        }
    }

    //2개의 시크바와 2개의 시간 뷰들 업데이트
    private fun updateSeekUi(duration:Long, position: Long) {

        binding?.let { binding ->

            binding.playListSeekBar.max = (duration / 1000).toInt()
            binding.playListSeekBar.progress = (position / 1000).toInt()

            binding.playerSeekBar.max = (duration / 1000).toInt()
            binding.playerSeekBar.progress = (position / 1000).toInt()

            binding.playTimeTextView.text = String.format("%02d:%02d",
                TimeUnit.MINUTES.convert(position, TimeUnit.MILLISECONDS),
                (position / 1000) % 60)
            binding.totalTimeTextView.text = String.format("%02d:%02d",
                TimeUnit.MINUTES.convert(duration, TimeUnit.MILLISECONDS),
                (duration / 1000) % 60)
        }
    }

    //지금 선택한 모델로 뷰들 업데이트
    private fun updatePlayerView(currentMusicModel: MusicModel?) {
        currentMusicModel ?: return

        binding?.let { binding ->
            binding.trackTextView.text = currentMusicModel.track
            binding.artistTextView.text = currentMusicModel.artist
            Glide.with(binding.coverImageView.context)
                .load(currentMusicModel.coverUrl)
                .into(binding.coverImageView)
        }
    }

    //리사이클러 뷰 초기화
    private fun initRecyclerView(fragmentPlayerBinding: FragmentPlayerBinding) {
        playListAdapter = PlayListAdapter {
            //콜백 함수로 재생
            playMusic(it)
        }

        fragmentPlayerBinding.playListRecyclerView.apply {
            adapter = playListAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    //재생 목록 버튼으로 재생목록 보여줄지 재생화면 보여줄지 선택
    private fun initPlayListButton(fragmentPlayerBinding: FragmentPlayerBinding) {
        fragmentPlayerBinding.playlistImageView.setOnClickListener {
            //예외처리 : 선택된 음악이 없는 경우? 서버에서 아직 다 못받아온 경우?
            if (model.currentPosition == -1) return@setOnClickListener

            //둘 중 하나는 가리고 하나는 보여줌
            fragmentPlayerBinding.playerViewGroup.isVisible = model.isWatchingPlayListView
            fragmentPlayerBinding.playListViewGroup.isVisible = model.isWatchingPlayListView.not()

            //뭐 보고 있는지 갱신
            model.isWatchingPlayListView = !model.isWatchingPlayListView
        }
    }

    //레트로 핏으로 음악들 가져오는 함수
    private fun getVideoListFromServer() {
        //모키가 체고야 ㄷㄷ;;;, 음악은 몰래 훔침 미친놈이
        val retrofit = Retrofit.Builder()
            .baseUrl("https://run.mocky.io")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        //다 알...지?
        retrofit.create(MusicService::class.java)
            .also {
                it.listMusics()
                    .enqueue(object : Callback<MusicDto> {
                        override fun onResponse(call: Call<MusicDto>, response: Response<MusicDto>) {

                            Log.d("PlayerFragment", "${response.body()}")

                            //이 아래부분 이해 못함
                            response.body()?.let { musicDto ->

                                model = musicDto.mapper()

                                setMusicList(model.getAdapterModels())
                                playListAdapter.submitList(model.getAdapterModels())

                            }
                        }

                        override fun onFailure(call: Call<MusicDto>, t: Throwable) {

                        }


                    })

            }


    }

    //미리 음악 목록들 저장 및 플래이어 준비
    private fun setMusicList(modelList: List<MusicModel>) {
        context?.let {
            //MusicMoel을 미디어 아이템으로 바꿔서 삽입
            player?.addMediaItems(modelList.map { musicModel ->
                MediaItem.Builder()
                        //나중에 편하개 찾기 위해 아이디 등록
                    .setMediaId(musicModel.id.toString())
                    .setUri(musicModel.streamUrl)
                    .build()
            })

            player?.prepare()
        }
    }

    //음악 재생
    private fun playMusic(musicModel: MusicModel) {
        //모델한테 최신화 시키기
        model.updateCurrentPosition(musicModel)
        player?.seekTo(model.currentPosition, 0)
        player?.play()
    }

    override fun onStop() {
        super.onStop()

        player?.pause()
        view?.removeCallbacks(updateSeekRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()

        binding = null
        player?.release()
        view?.removeCallbacks(updateSeekRunnable)
    }

    //뉴인스턴스 라는 함수로 만들었기 때문에 프래그먼트 반환, 메인에서 인자를 받아오기 편함
    companion object {
        fun newInstance(): PlayerFragment {
            return PlayerFragment()
        }
    }

}