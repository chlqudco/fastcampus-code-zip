package fastcampus.aop.part5.chapter07.domain.model

data class ReviewedMovie(
    val movie: Movie,
    val myReview: Review
)
