package com.chlqudco.develop.todo.di

import com.chlqudco.develop.todo.data.repository.TestToDoRepository
import com.chlqudco.develop.todo.data.repository.ToDoRepository
import com.chlqudco.develop.todo.domain.todo.*
import com.chlqudco.develop.todo.presentation.detail.DetailMode
import com.chlqudco.develop.todo.presentation.detail.DetailViewModel
import com.chlqudco.develop.todo.presentation.list.ListViewModel
import org.koin.dsl.module
import org.koin.android.viewmodel.dsl.viewModel

internal val appTestModule = module {

    factory { GetToDoListUseCase(get()) }
    factory { GetToDoItemUseCase(get()) }
    factory { InsertToDoListUseCase(get()) }
    factory { InsertToDoUseCase(get()) }
    factory { DeleteToDoItemUseCase(get()) }
    factory { DeleteAllToDoItemUseCase(get()) }
    factory { UpdateToDoUseCase(get()) }

    single<ToDoRepository> { TestToDoRepository() }

    viewModel { ListViewModel(get(), get(), get()) }
    viewModel { (detailMode: DetailMode, id: Long) -> DetailViewModel(detailMode, id, get(), get(), get(), get()) }

}
