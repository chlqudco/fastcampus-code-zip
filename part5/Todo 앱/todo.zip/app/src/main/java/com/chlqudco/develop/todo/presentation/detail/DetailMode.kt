package com.chlqudco.develop.todo.presentation.detail

enum class DetailMode {
    DETAIL, WRITE
}
