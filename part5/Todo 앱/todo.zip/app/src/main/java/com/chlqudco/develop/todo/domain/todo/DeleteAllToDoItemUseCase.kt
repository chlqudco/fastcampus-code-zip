package com.chlqudco.develop.todo.domain.todo

import com.chlqudco.develop.todo.data.repository.ToDoRepository
import com.chlqudco.develop.todo.domain.UseCase

internal class DeleteAllToDoItemUseCase(
    private val toDoRepository: ToDoRepository
): UseCase {

    suspend operator fun invoke() {
        return toDoRepository.deleteAll()
    }

}
