package com.chlqudco.develop.todo.domain

internal interface UseCase
