package com.chlqudco.develop.todo.domain.todo

import com.chlqudco.develop.todo.data.entity.ToDoEntity
import com.chlqudco.develop.todo.data.repository.ToDoRepository
import com.chlqudco.develop.todo.domain.UseCase


internal class InsertToDoUseCase(
    private val toDoRepository: ToDoRepository
): UseCase {

    suspend operator fun invoke(toDoEntity: ToDoEntity): Long {
        return toDoRepository.insertToDoItem(toDoEntity)
    }

}
