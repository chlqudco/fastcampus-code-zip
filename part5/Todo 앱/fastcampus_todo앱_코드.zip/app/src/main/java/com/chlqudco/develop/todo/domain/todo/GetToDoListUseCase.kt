package com.chlqudco.develop.todo.domain.todo

import com.chlqudco.develop.todo.data.entity.ToDoEntity
import com.chlqudco.develop.todo.data.repository.ToDoRepository
import com.chlqudco.develop.todo.domain.UseCase


internal class GetToDoListUseCase(
    private val toDoRepository: ToDoRepository
): UseCase {

    suspend operator fun invoke(): List<ToDoEntity> {
        return toDoRepository.getToDoList()
    }

}
