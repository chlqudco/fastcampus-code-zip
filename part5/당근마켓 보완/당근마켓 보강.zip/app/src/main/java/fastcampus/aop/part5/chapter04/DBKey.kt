package fastcampus.aop.part5.chapter04

class DBKey {
    companion object {
        const val DB_ARTICLES = "Articles"
        const val DB_USERS = "Users"
        const val DB_CHATS = "Chats"
        const val CHILD_CHAT = "chat"
    }
}
