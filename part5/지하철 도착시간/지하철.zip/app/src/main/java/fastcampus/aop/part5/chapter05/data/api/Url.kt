package fastcampus.aop.part5.chapter05.data.api

object Url {
    const val SEOUL_DATA_API_URL = "http://swopenapi.seoul.go.kr/"
}
