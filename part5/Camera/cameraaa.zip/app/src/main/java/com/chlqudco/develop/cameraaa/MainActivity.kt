package com.chlqudco.develop.cameraaa

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.media.MediaScannerConnection
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.core.ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
import androidx.camera.core.ImageCapture.FLASH_MODE_AUTO
import androidx.camera.core.impl.ImageOutputConfig
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chlqudco.develop.cameraaa.ImageListActivity.Companion.IMAGE_LIST_REQUEST_CODE
import com.chlqudco.develop.cameraaa.databinding.ActivityMainBinding
import com.chlqudco.develop.cameraaa.extensions.clear
import com.chlqudco.develop.cameraaa.extensions.loadCenterCrop
import com.chlqudco.develop.cameraaa.util.PathUtil
import java.io.File
import java.io.FileNotFoundException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var cameraExecutor: ExecutorService
    private val cameraMainExecutor by lazy { ContextCompat.getMainExecutor(this) }

    private lateinit var imageCapture: ImageCapture
    // 카메라 얻어오면 이후 실행 리스너 등록
    private val cameraProviderFuture by lazy { ProcessCameraProvider.getInstance(this) }


    private var camera: Camera? = null

    private var root: View? = null

    //저장중임?
    private var isCapturing: Boolean = false
    //플래시 킴?
    private var isFlashEnabled: Boolean = false

    //미리보기로 저장한 사진들
    private var uriList = mutableListOf<Uri>()

    // 디스플레이 친구들
    private var displayId: Int = -1
    private val displayManager by lazy { getSystemService(Context.DISPLAY_SERVICE) as DisplayManager }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (this@MainActivity.displayId == displayId) {
                if (::imageCapture.isInitialized && root != null) {
                    imageCapture.targetRotation = root?.display?.rotation ?: ImageOutputConfig.INVALID_ROTATION
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        root = binding.root
        if (allPermissionsGranted()) {
            startCamera(binding.viewFinder)
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }
    }

    //권한 다 받아져 있음?
    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    //화면에 카메라 화면 나타내기
    private fun startCamera(viewFinder: PreviewView) {
        //디스플레이 매니저 초기화
        displayManager.registerDisplayListener(displayListener, null)
        //익스큐터 초기화
        cameraExecutor = Executors.newSingleThreadExecutor()

        //10밀리 마다 화면갱ㅅㄴ
        viewFinder.postDelayed({
            displayId = viewFinder.display.displayId
            bindCameraUseCase() },
            10)
    }

    //진짜로 화면에 보여주기
    private fun bindCameraUseCase() = with(binding) {
        // 회전 값 가져오기
        val rotation = viewFinder.display.rotation
        // 카메라 설정(후면)
        val cameraSelector = CameraSelector.Builder().requireLensFacing(LENS_FACING).build()

        //카메라 초기 설정
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().apply {
                setTargetAspectRatio(AspectRatio.RATIO_4_3)
                setTargetRotation(rotation)
            }.build()

            // 화면 어떻게 나타낼지 초기화
            val builder = ImageCapture.Builder()
                .setCaptureMode(CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(rotation)
                .setFlashMode(FLASH_MODE_AUTO)

            //합체
            imageCapture = builder.build()

            try {
                // 기존에 바인딩 되어 있는 카메라는 해제해주어야 함
                cameraProvider.unbindAll()
                //나머지 요소들 전부 초기화
                camera = cameraProvider.bindToLifecycle(this@MainActivity, cameraSelector, preview, imageCapture)
                preview.setSurfaceProvider(viewFinder.surfaceProvider)
                bindCaptureListener()
                bindZoomListener()
                bindLightSwitchListener()
                bindPreviewImageViewClickListener()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, cameraMainExecutor)

    }

    //줌인 줌아웃 리스너
    @SuppressLint("ClickableViewAccessibility")
    private fun bindZoomListener() = with(binding) {
        val listener = object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                //현재 줌 한 비율 정보?ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ 존나 기네 씹싸쓰껏
                val currentZoomRatio = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
                //얘가 진짜 비율이래
                val delta = detector.scaleFactor
                camera?.cameraControl?.setZoomRatio(currentZoomRatio * delta)
                return true
            }
        }
        //제스처 디텍터에 리스너 등록
        val scaleGestureDetector = ScaleGestureDetector(this@MainActivity, listener)

        //뷰에 리스너 등록
        viewFinder.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            return@setOnTouchListener true
        }
    }

    //화면 캡쳐 리스너
    private fun bindCaptureListener() = with(binding) {
        captureButton.setOnClickListener {
            if (!isCapturing) {
                isCapturing = true
                captureCamera()
            }
        }
    }

    //플래시 껐다 켰다
    private fun bindLightSwitchListener() = with(binding) {
        flashSwitch.setOnCheckedChangeListener { _, isChecked ->
            isFlashEnabled = isChecked
        }
    }

    //내가 찍은 사진 보러가기 버튼
    private fun bindPreviewImageViewClickListener() = with(binding) {
        previewImageVIew.setOnClickListener {
            startActivityForResult(ImageListActivity.newIntent(this@MainActivity, uriList), IMAGE_LIST_REQUEST_CODE)
        }
    }

    //저장한 사진의 uri를 갖고 있기 위해
    private var contentUri: Uri? = null

    //촬영
    private fun captureCamera() {
        if (!::imageCapture.isInitialized) return
        //어디에 저장할지와 파일명 지정
        val photoFile = File(PathUtil.getOutputDirectory(this),
            SimpleDateFormat(FILENAME_FORMAT, Locale.KOREA).format(System.currentTimeMillis()) + ".jpg")

        //옵션 지정
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        //플래시 켰으면 켜기
        if (isFlashEnabled) flashLight(true)
        imageCapture.takePicture(outputOptions, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            //다 저장 되면
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val savedUri = outputFileResults.savedUri ?: Uri.fromFile(photoFile)
                val rotation = binding.viewFinder.display.rotation // 회전 값 설정. ?? 안쓰는데 왜 지정?
                contentUri = savedUri
                updateSavedImageContent()
            }

            override fun onError(e: ImageCaptureException) {
                e.printStackTrace()
                isCapturing = false
            }
        })

    }

    //플래시 켜!
    private fun flashLight(light: Boolean) {
        val hasFlash = camera?.cameraInfo?.hasFlashUnit()
        if (true == hasFlash) {
            camera?.cameraControl?.enableTorch(light)
        }
    }

    //이미지 저장된걸 외부에 알림
    private fun updateSavedImageContent() {
        contentUri?.let {
            isCapturing = try {
                //파일 불러오기
                val file = File(PathUtil.getPath(this, it) ?: throw FileNotFoundException())
                //외부에 알리기
                MediaScannerConnection.scanFile(this, arrayOf(file.path), arrayOf("image/jpeg"), null)
                //미리보기? 결과? 화면에 찍은거 집어넣기
                Handler(Looper.getMainLooper()).post {
                    binding.previewImageVIew.loadCenterCrop(url = it.toString(), corner = 4f)
                }
                if (isFlashEnabled) flashLight(false)
                uriList.add(it)
                false
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
                false
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera(binding.viewFinder)
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ImageListActivity.IMAGE_LIST_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            uriList = data?.getParcelableArrayListExtra(ImageListActivity.URI_LIST_KEY) ?: uriList
            if (uriList.isNotEmpty()) {
                binding.previewImageVIew.loadCenterCrop(url = uriList.first().toString(), corner = 4f)
            } else {
                binding.previewImageVIew.clear()
            }
        }
    }

    companion object {
        const val TAG = "MainActivity"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private val LENS_FACING: Int = CameraSelector.LENS_FACING_BACK
    }
}