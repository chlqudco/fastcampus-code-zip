package com.chlqudco.develop.cameraaa

import android.app.Activity
import android.content.Intent
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.viewpager2.widget.ViewPager2
import com.chlqudco.develop.cameraaa.adapter.ImageViewPagerAdapter
import com.chlqudco.develop.cameraaa.databinding.ActivityImageListBinding
import com.chlqudco.develop.cameraaa.util.PathUtil
import java.io.File
import java.io.FileNotFoundException

class ImageListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImageListBinding
    private val uriList by lazy<List<Uri>> { intent.getParcelableArrayListExtra(URI_LIST_KEY)!! }
    private lateinit var imageViewPagerAdapter: ImageViewPagerAdapter
    private var currentUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initViews()
    }

    //뷰 초기화
    private fun initViews() {
        //놀랍게도 내장함수
        setSupportActionBar(binding.toolbar)
        setupImageList(uriList)
    }

    private fun setupImageList(uriList: List<Uri>) = with(binding) {
        //어댑터 초기화
        if (::imageViewPagerAdapter.isInitialized.not()) {
            imageViewPagerAdapter = ImageViewPagerAdapter(uriList.toMutableList())
        }
        imageViewPager.adapter = imageViewPagerAdapter

        //인디케이터와 뷰페이져 연결, 단 한줄로 끝
        indicator.setViewPager(imageViewPager)

        //화면 옮기면 발생하는 이벤토
        imageViewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                //몇번 째 사진인지, 개쓸모없음음
               toolbar.title = if (imageViewPagerAdapter.uriList.isNotEmpty()) {
                    currentUri = imageViewPagerAdapter.uriList[position]
                    getString(R.string.images_page, position + 1, imageViewPagerAdapter.uriList.size)
                } else {
                    currentUri = null
                    ""
                }
            }
        })
        deleteButton.setOnClickListener {
            currentUri?.let { uri ->
                removeImage(uri)
            }
        }
    }

    //뒤로 가기 누르면 원래 화면으로 돌아가기, 정보를 넣어서
    override fun onBackPressed() {
        setResult(Activity.RESULT_OK, Intent().apply {
            putExtra(URI_LIST_KEY, ArrayList<Uri>().apply { imageViewPagerAdapter.uriList.forEach { add(it) } })
        })
        finish()
    }

    //이미지 함수
    private fun removeImage(uri: Uri) {
        //파일 불러와서 지우기
        val file = File(PathUtil.getPath(this, uri) ?: throw FileNotFoundException())
        file.delete()

        //나머지 요소들도 없데이트 하기
        val removedIndex = imageViewPagerAdapter.uriList.indexOf(uri)
        imageViewPagerAdapter.uriList.removeAt(removedIndex)
        imageViewPagerAdapter.notifyItemRemoved(removedIndex)
        binding.indicator.setViewPager(binding.imageViewPager)

        if (imageViewPagerAdapter.uriList.isNotEmpty()) {
            currentUri = if (removedIndex == 0) {
                imageViewPagerAdapter.uriList[removedIndex]
            } else {
                imageViewPagerAdapter.uriList[removedIndex - 1]
            }
        }

        MediaScannerConnection.scanFile(this, arrayOf(file.path), arrayOf(file.name)) { _, _ ->
            contentResolver.delete(uri, null, null)
        }

        //비어있으면 강제 뒤로가기
        if (imageViewPagerAdapter.uriList.isEmpty()) {
            Toast.makeText(this, "삭제할 수 있는 이미지가 없습니다.", Toast.LENGTH_SHORT).show()
            onBackPressed()
        } else {
            binding.toolbar.title = getString(R.string.images_page, removedIndex + 1, imageViewPagerAdapter.uriList.size)
        }
    }

    companion object {
        const val URI_LIST_KEY = "uriList"
        const val IMAGE_LIST_REQUEST_CODE = 100
        //여기서 안씀, 메인에서 저장한 것들 여기에 저장하려고 여기서 함수 정의
        fun newIntent(activity: Activity, uriList: List<Uri>) =
            Intent(activity, ImageListActivity::class.java).apply {
                putExtra(URI_LIST_KEY, ArrayList<Uri>().apply { uriList.forEach { add(it) } })
            }
    }
}
