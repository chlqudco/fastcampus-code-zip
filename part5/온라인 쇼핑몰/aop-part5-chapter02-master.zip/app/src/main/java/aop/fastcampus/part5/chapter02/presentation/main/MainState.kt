package aop.fastcampus.part5.chapter02.presentation.main

sealed class MainState {

    object RefreshOrderList: MainState()

}
