package aop.fastcampus.part5.chapter02.data.network

object Url {

    const val PRODUCT_BASE_URL = "https://6083a15d5dbd2c001757b94a.mockapi.io/part5/chapter02/"

}
