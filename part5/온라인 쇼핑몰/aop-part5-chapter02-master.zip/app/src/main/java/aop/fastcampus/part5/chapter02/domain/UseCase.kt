package aop.fastcampus.part5.chapter02.domain

interface UseCase {



}
