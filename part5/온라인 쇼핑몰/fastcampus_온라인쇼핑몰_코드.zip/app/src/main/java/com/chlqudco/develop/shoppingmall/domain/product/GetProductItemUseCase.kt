package com.chlqudco.develop.shoppingmall.domain.product

import com.chlqudco.develop.shoppingmall.domain.UseCase
import com.chlqudco.develop.shoppingmall.data.entity.product.ProductEntity
import com.chlqudco.develop.shoppingmall.data.repository.ProductRepository

internal class GetProductItemUseCase(
    private val productRepository: ProductRepository
): UseCase {

    suspend operator fun invoke(productId: Long): ProductEntity? {
        return productRepository.getProductItem(productId)
    }

}
