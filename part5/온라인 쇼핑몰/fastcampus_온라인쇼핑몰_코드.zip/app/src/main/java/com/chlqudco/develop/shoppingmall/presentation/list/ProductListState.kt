package com.chlqudco.develop.shoppingmall.presentation.list

import com.chlqudco.develop.shoppingmall.data.entity.product.ProductEntity

internal sealed class ProductListState {

    object UnInitialized: ProductListState()

    object Loading: ProductListState()

    data class Success(
        val productList: List<ProductEntity>
    ): ProductListState()

    object Error: ProductListState()

}
