package com.chlqudco.develop.shoppingmall.domain.product

import com.chlqudco.develop.shoppingmall.domain.UseCase
import com.chlqudco.develop.shoppingmall.data.repository.ProductRepository

internal class DeleteOrderedProductListUseCase(
    private val productRepository: ProductRepository
): UseCase {

    suspend operator fun invoke() {
        return productRepository.deleteAll()
    }

}
