package com.chlqudco.develop.shoppingmall.data.response

data class ProductsResponse(
    val items: List<ProductResponse>,
    val count: Int
)
