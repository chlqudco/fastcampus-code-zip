package com.chlqudco.develop.shoppingmall.di

import com.chlqudco.develop.shoppingmall.data.db.provideDB
import com.chlqudco.develop.shoppingmall.data.db.provideToDoDao
import com.chlqudco.develop.shoppingmall.data.network.*
import com.chlqudco.develop.shoppingmall.data.network.provideProductRetrofit
import com.chlqudco.develop.shoppingmall.data.preference.PreferenceManager
import com.chlqudco.develop.shoppingmall.data.repository.DefaultProductRepository
import com.chlqudco.develop.shoppingmall.data.repository.ProductRepository
import com.chlqudco.develop.shoppingmall.domain.product.DeleteOrderedProductListUseCase
import com.chlqudco.develop.shoppingmall.domain.product.GetOrderedProductListUseCase
import com.chlqudco.develop.shoppingmall.domain.product.GetProductItemUseCase
import com.chlqudco.develop.shoppingmall.domain.product.GetProductListUseCase
import com.chlqudco.develop.shoppingmall.domain.product.OrderProductItemUseCase
import com.chlqudco.develop.shoppingmall.presentation.detail.ProductDetailViewModel
import com.chlqudco.develop.shoppingmall.presentation.list.ProductListViewModel
import com.chlqudco.develop.shoppingmall.presentation.main.MainViewModel
import com.chlqudco.develop.shoppingmall.presentation.profile.ProfileViewModel
import kotlinx.coroutines.Dispatchers
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

internal val appModule = module {

    single { Dispatchers.Main }
    single { Dispatchers.IO }

    // ViewModel
    viewModel { MainViewModel() }
    viewModel { ProductListViewModel(get()) }
    viewModel { ProfileViewModel(get(), get(), get()) }
    viewModel { (productId: Long) -> ProductDetailViewModel(productId, get(), get()) }

    // UseCase
    factory { GetProductListUseCase(get()) }
    factory { GetOrderedProductListUseCase(get()) }
    factory { GetProductItemUseCase(get()) }
    factory { OrderProductItemUseCase(get()) }
    factory { DeleteOrderedProductListUseCase(get()) }

    // Repository
    single<ProductRepository> { DefaultProductRepository(get(), get(), get()) }

    single { provideGsonConverterFactory() }

    single { buildOkHttpClient() }

    single { provideProductRetrofit(get(), get()) }

    single { provideProductApiService(get()) }

    single { PreferenceManager(androidContext()) }

    // Database
    single { provideDB(androidApplication()) }
    single { provideToDoDao(get()) }

}

