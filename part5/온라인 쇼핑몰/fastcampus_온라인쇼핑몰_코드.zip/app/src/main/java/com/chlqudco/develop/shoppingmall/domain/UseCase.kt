package com.chlqudco.develop.shoppingmall.domain

interface UseCase {



}
