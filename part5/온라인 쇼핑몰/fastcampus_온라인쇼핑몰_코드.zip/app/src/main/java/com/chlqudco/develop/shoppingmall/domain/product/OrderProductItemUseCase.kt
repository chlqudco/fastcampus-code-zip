package com.chlqudco.develop.shoppingmall.domain.product

import com.chlqudco.develop.shoppingmall.domain.UseCase
import com.chlqudco.develop.shoppingmall.data.entity.product.ProductEntity
import com.chlqudco.develop.shoppingmall.data.repository.ProductRepository

internal class OrderProductItemUseCase(
    private val productRepository: ProductRepository
): UseCase {

    suspend operator fun invoke(productEntity: ProductEntity): Long {
        return productRepository.insertProductItem(productEntity)
    }

}
