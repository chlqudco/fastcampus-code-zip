package com.chlqudco.develop.shoppingmall.presentation.main

sealed class MainState {

    object RefreshOrderList: MainState()

}
