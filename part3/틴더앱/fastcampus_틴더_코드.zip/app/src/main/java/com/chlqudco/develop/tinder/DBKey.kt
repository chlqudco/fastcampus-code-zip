package com.chlqudco.develop.tinder

class DBKey {
    companion object {
        const val USERS = "Users"
        const val LIKED_BY = "likedBy"
        const val LIKE = "like"
        const val DIS_LIKE = "disLike"
        const val USER_ID = "userId"
        const val NAME = "name"
        const val MATCH = "match"
    }
}