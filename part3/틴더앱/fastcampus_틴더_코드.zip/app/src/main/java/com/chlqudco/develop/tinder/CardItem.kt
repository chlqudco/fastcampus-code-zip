package com.chlqudco.develop.tinder

data class CardItem(
    val userId: String,
    var name: String
)