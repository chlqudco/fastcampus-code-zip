package com.chlqudco.develop.market.chatdetail

data class ChatItem(
    var senderId: String,
    val message: String
) {

    constructor(): this("", "")
}
