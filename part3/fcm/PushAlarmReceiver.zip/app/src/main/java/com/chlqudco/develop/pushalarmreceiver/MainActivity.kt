package com.chlqudco.develop.pushalarmreceiver

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.firebase.messaging.FirebaseMessaging
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    private val resultTextView : TextView by lazy { findViewById(R.id.resultTextView) }
    private val firebaseTokenTextView : TextView by lazy { findViewById(R.id.firebaseTokenTextView) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initFirebase()
        updateResult()
    }

    //싱글 탑으로 새로 눌렀을 경우
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        setIntent(intent)
        updateResult(true)
    }

    private fun initFirebase() {
        //토큰 가져오기
        FirebaseMessaging.getInstance().token.addOnCompleteListener {
            if (it.isSuccessful){
                firebaseTokenTextView.text = it.result
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateResult(isNewIntent : Boolean = false){
        resultTextView.text = (intent.getStringExtra("notificationType") ?: "앱 런처") +
                if (isNewIntent){
                    "(으)로 갱신했습니다."
                }else{
                    "(으)로 실행했습니다."
                }
    }
}