package com.chlqudco.develop.todaygoodsentence

data class Quote(
    val quote : String,
    val name : String
)
