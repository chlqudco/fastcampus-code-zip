package com.chlqudco.develop.airbnb

data class HouseDto(
    val items: List<HouseModel>
)